#ifndef APG_API_H
#define APG_API_H	

#include <stdio.h>

extern char _hund;
extern char _sec;
extern char _minute;

#define byte			unsigned char
#define word			unsigned short

#define INIT_RESUME		0									// point define command.. none���� ó���Ѵ�. 

extern float iPget(int n_data);
extern void iPset(int n_data, float f_val);

extern void PdefDo2s(byte pcm, byte pno, byte opt);
extern void PdefVo(byte pcm, byte pno, float f_hyst, float f_scale, float f_offset, float f_min, float f_max);
extern void PdefJpt1000(byte pcm, byte pno, float f_hyst, float f_offset, float f_min, float f_max);
extern void PdefDi2s(byte pcm, byte pno);
extern void PdefVi(byte pcm, byte pno, float f_hyst, float f_scale, float f_offset, float f_min, float f_max);
extern void PdefCi(byte pcm, byte pno, float f_hyst, float f_scale, float f_offset, float f_min, float f_max);
extern void PdefVr(byte pcm, byte pno, float f_hyst, float f_min, float f_max);


#endif
