make -s  clean
echo "   CL   lib_duksan.a"
make -s 
echo "   MK   lib_duksan.a"
arm-linux-gcc -c -Wall -I./ test.c
arm-linux-gcc -lpthread -o test test.o lib_duksan.a
cp test /root/AESOP/duksan/APP/test





