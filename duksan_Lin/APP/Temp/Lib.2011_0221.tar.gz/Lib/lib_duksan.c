/* file : lib_duksan.c
 * author : jong2ry@imecasys.com
 * 
 * 
 * User�� ����� Library file�� �����Ѵ�.  
 *  
 *  
 *  pset request / response format
 *  pget request / response format
 *  
 *  | length (2byye) | cmd('S' or 'G') | pcm (1byte) | pno (2byte) | value (4byte) | .... | 0x00 (1byte) | chksum (1byte) |
 *  
 *  <-- header --->   <--------------------------- data -------------------------->        <-------- chksum-------------->
 *  
 *  data ������ APG Application���� ��û�ϴ� �� ��ŭ �ݺ��ȴ�.
 * 
 *  
 *  
 *  pdef request format 
 *  
 *  | length (2byye) |
 *  
 * 	<-- header --->
 *  
 * 	|cmd('D') | pcm (1byte) | pno (2byte) | type (4byte) | hist (4byte) | scale (4byte) | offset (4byte) | min (4byte) | max (4byte) |
 *  
 *   <-------------------------------------------------------- data ---------------------------------------------------------------->
 * 	   
 *  | 0x00 (1byte) | chksum (1byte) |
 *  
 *  <-------- chksum-------------->
 *  
 *  
 *  
 *  pdef response format
 *  
 *  | length (2byye) | cmd('S' or 'G') | pcm (1byte) | pno (2byte) | value (4byte) | 0x00 (1byte) | chksum (1byte) |
 *  
 *  <-- header --->   <--------------------------- data --------------------------> <-------- chksum-------------->
 *  
 *  
 * 
 * version :
 *  	0.0.1 - initiailize									2010-07-26
 *  	0.0.2 - px, py ����									2010-07-27
 *  	0.0.3 - point define ����							2010-07-28
 *  
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <sys/stat.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/time.h>										// gettimeofday();
#include <time.h>
#include <sys/un.h>
#include <sys/poll.h>										// use poll event

#include "lib_queue.h"
#include "lib_duksan.h"

char _hund = 0;												// hund timer value
char _sec = 0;												// sec timer value
char _minute = 0;											// minute timer value

struct timeval now_time;									// gettimeofday now value
struct timeval pre_time;									// gettimeofday pre value

int client_socket;											// library file socket
struct sockaddr_un server_addr;								// library file socket address
point_queue lib_queue;										// lib queue	

float g_ptbl[32][256];										// temp point table

unsigned char tx_msg[4028];									// tx message buffer
unsigned char rx_msg[4028];									// rx message buffer

int gn_id;													// my pcm number

int gn_sendtype;											// send message type.

// user application function.
extern void ApgMain(void);
extern void PointDefine(void);


void lib_sleep(int sec, int msec) 
// ----------------------------------------------------------------------------
// WAIT TIMER
// Description : use select function for timer.
// Arguments   : sec		Is a second value.
//				 usec		Is a micro-second value. 
// Returns     : none
{
    struct timeval tv;
    tv.tv_sec = sec;
    tv.tv_usec = msec * 1000;                
    select(0,NULL,NULL,NULL,&tv);
    return;
}


float iPget(int n_data) 
// ----------------------------------------------------------------------------
// Get point value
// Description : User App���� ��û�� ����, g_ptbl�� ���� �����Ѵ�. 
// 				 �׸��� ���ο� ���� �����ϱ� ���� lib_queue�� 
// 				 data���� ��û�ϴ� �޽����� ������. 
// Arguments   : n_data					Py���� ������ ��
// Returns     : value					User App�� ��û�� ��
{
	point_info point;

	point.pcm = LIB_PCM(n_data);
	point.pno = LIB_PNO(n_data);
	point.value = 0;
	point.message_type = LIB_PGET_REQUEST;

	putq(&lib_queue, &point);	

	//fprintf( stdout, ">>> iPget %d (%d %d)\n", n_data, LIB_PCM(n_data), LIB_PNO(n_data) );
	//fflush(stdout);

	return g_ptbl[LIB_PCM(n_data)][LIB_PNO(n_data)];
}


void iPset(int n_data, float f_val)
// ----------------------------------------------------------------------------
// Set point value
// Description : User App���� ��û�� ����, lib_queue�� data���� ���� 
// 				 �޽����� ������. 
// Arguments   : n_data					Px���� ������ ��
// 				 f_val					Value
// Returns     : none
{
	point_info point;

	point.pcm = LIB_PCM(n_data);
	point.pno = LIB_PNO(n_data);
	point.value = f_val;
	point.message_type = LIB_PSET_REQUEST;

	putq(&lib_queue, &point);	

	//fprintf( stdout, ">>> iPset %d (%d %d) %f\n", n_data, LIB_PCM(n_data), LIB_PNO(n_data), f_val );
	//fflush(stdout);
}


int lib_create_sock(void)
// ----------------------------------------------------------------------------
// Create File Socket
// Description : duksan app�� ����ϱ����� file socket�� �����Ѵ�. 
// Arguments   : none
// Returns     : 1						If successful
//				 -1 					If Fail
{
	client_socket = socket( PF_FILE, SOCK_STREAM, 0);
	if( -1 == client_socket) {
		fprintf( stdout, "[ERR] Socket Create Error\n" );
		fflush(stdout);
		return -1;
	}

	memset( &server_addr, 0, sizeof( server_addr));
	server_addr.sun_family  = AF_UNIX;
	strcpy( server_addr.sun_path, FILE_SERVER);

	if( -1 == connect( client_socket, (struct sockaddr*)&server_addr, sizeof( server_addr) ) ) {
		fprintf( stdout, "[ERR] Fail Connect Error\n" );
		fflush(stdout);
		return -1;
	}

	return 1;
}


int lib_send_msg(int n_type)
// ----------------------------------------------------------------------------
// MESSAGE MAKE AND SEND
// Description : type�� �µ��� message�� ����� �����Ѵ�. 
// Arguments   : type					Send message type
// Returns     : 1						If successful
//				 -1 					If Fail
{
	int i = 0;
	int n_cnt = 0;
	int n_ret = 0;
	int n_pnt = 0;
	int n_length = 0;
	unsigned char c_chksum = 0;
	point_info point;
	APG_DATA_FORMAT_T *p_data;

	memset( tx_msg, 0x00, sizeof(tx_msg) );


	switch ( n_type ) {
	// �ʱ� startup message 
	case LIB_SEND_TYPE_STATUP:
		gn_sendtype = LIB_SEND_TYPE_STATUP;

		tx_msg[0] = 0x00;
		tx_msg[1] = 0x04;
		tx_msg[2] = LIB_STARTUP_REQUEST;
		tx_msg[3] = 0x00;

		n_length = 4;										// length fixed
		break;

	// point define message 
	case LIB_SEND_TYPE_PDEF:
		gn_sendtype = LIB_SEND_TYPE_PDEF;
		break;

	// point set / get message 
	case LIB_SEND_TYPE_NONE:
		gn_sendtype = LIB_SEND_TYPE_NONE;
		for (;;) {
			// get queue.
			n_ret = getq( &lib_queue, &point );

			if ( n_ret == SUCCESS ) {
				// get data pointer
				n_pnt = 2 + (8 * n_cnt);
				p_data = (APG_DATA_FORMAT_T *) &tx_msg[n_pnt];	

				// get value
				p_data->c_pcm = point.pcm;
				p_data->w_pno = point.pno;
				p_data->f_val = point.value;
				p_data->c_cmd = point.message_type;

				n_cnt++;
			}
			else
				break;
		}

		// calculate total length
		n_length = (n_cnt * 8) + 4;
		tx_msg[0] = (n_length >> 8) & 0x00ff;
		tx_msg[1] = n_length & 0x00ff;
		break;
	}


	// calculate total chksum
	c_chksum = 0;
	for ( i = 0; i < n_length - 1; i++ ) {
		c_chksum -= tx_msg[i];
	}
	tx_msg[n_length - 1] = c_chksum;

	/* 
	// Chksum test code. 
	//
	c_chksum = 0;
	for ( i = 0; i < n_length; i++ ) {
		c_chksum += tx_msg[i];
	}

	fprintf( stdout, "c_chksum = %d\n", c_chksum );
	fflush(stdout);
	*/

	// send message
	if( write( client_socket, tx_msg, n_length ) <= 0) {
		fprintf( stdout, "[ERR] Send in lib_send_msg()\n" );
		fflush(stdout);
		return -1;
	}	
}


int lib_recv_msg(void)
// ----------------------------------------------------------------------------
// MESSAGE RECEIVE 
// Description : duksan app�κ��� message�� �޴´�.  
// Arguments   : none
// Returns     : length					receive message length
{
	int length;

	length = read ( client_socket, rx_msg, sizeof(rx_msg) );

	return length;
}


void lib_handler(void)
// ----------------------------------------------------------------------------
// PARSING MESSAGE
// Description : duksan app�κ��� message�� �м��Ͽ� ó���Ѵ�. 
// Arguments   : none
// Returns     : none
{
	int i = 0;
	point_info point;
	unsigned int n_pnt = 0;
	unsigned int n_cnt = 0;
	unsigned int n_length = 0;
	unsigned char c_chksum = 0;
	APG_DATA_FORMAT_T *p_data = NULL;

	n_length = ((rx_msg[0] << 8) & 0xff00) + rx_msg[1];
	//fprintf( stdout,  ">> Res n_length %d ( %x, %x)\n", n_length, rx_msg[0], rx_msg[1] );
	//fflush(stdout);

	// check chksum 
	c_chksum = 0;
	for ( i = 0; i < n_length; i++ ) {
		c_chksum += rx_msg[i];
	}
	//fprintf( stdout, ">> Res c_chksum = %d\n", c_chksum );
	//fflush(stdout);
	
	if ( c_chksum != 0 ) {
		return;
	}

	// Startup code only.
	if ( n_length == 4 && gn_sendtype == LIB_SEND_TYPE_STATUP ) {
		gn_id = rx_msg[2];
		fprintf( stdout, "Apg My Id %d\n", gn_id );
		fflush(stdout);
		return;
	}

	// (length - 4) / 8
	// ���⼭ 4�� length�� chksum�� byte ���̴�. 
	n_cnt = n_length;
	n_cnt = (n_cnt - 4) >> 3; 								
	//fprintf( stdout,  ">> Res n_cnt %d\n", n_cnt );
	//fflush(stdout);

	for ( i = 0; i < n_cnt; i++ ) {
		n_pnt = 2 + (8 * i);
		p_data = (APG_DATA_FORMAT_T *) &rx_msg[n_pnt];		

		g_ptbl[p_data->c_pcm][p_data->w_pno] =  p_data->f_val;

		/*
		fprintf( stdout,  ">>(%d) Res %d-%d  %f\n", 
				 i, 
				 p_data->c_pcm,
				 p_data->w_pno,
				 p_data->f_val);
		fflush(stdout);
		*/
	}

}


void lib_startup(void)
// ----------------------------------------------------------------------------
// APG APPLICATION STARTUP
// Description : ���ʷ� duksan app�� ������ �� startup message�� �ְ� �޴´�.
// 				 �� �۾��� ���� �ڽ��� pcm ��ȣ�� ���´�. 
// Arguments   : none
// Returns     : none
{
	int n_length = 0;

	// Create apg socket
	if ( lib_create_sock() < 0 ) {
		exit(0);
	}
	fprintf( stdout, "[APG] Startup Socket Create\n" );
	fflush(stdout);

	// send message
	if ( lib_send_msg(LIB_SEND_TYPE_STATUP) < 0 ) {
		exit(0);
	}
	lib_sleep(0, 40);
	fprintf( stdout, "[APG] Startup Send Message\n" );
	fflush(stdout);

	// receive message and handler message....!!! 
	n_length = lib_recv_msg();
	if ( n_length > 0 ) {
		lib_handler();
	}

	fprintf( stdout, "[APG] Startup Receive Message\n" );
	fflush(stdout);

	close(client_socket);
}



int main(void)
// ----------------------------------------------------------------------------
// MAIN LOOP
// Description : hund, sec, minute timer�� Value ���� �����Ѵ�. 
// 				 ApgMain() �� ȣ���Ѵ�. 
// Arguments   : sec		Is a second value.
//				 usec		Is a micro-second value. 
// Returns     : none
{
	int n_length = 0;
	int n_chk_time = 0;

	gettimeofday(&now_time, NULL);
	gettimeofday(&pre_time, NULL);

	initq(&lib_queue);
	memset ( &g_ptbl, 0x00, sizeof(g_ptbl) );

	// startup code. get gn_id
	lib_startup();

	// user function. point define.
	fprintf( stdout, "[APG] Point define Start\n" );
	fflush(stdout);

	PointDefine();

	fprintf( stdout, "[APG] Point define End\n" );
	fflush(stdout);


	while(1) {
		// 1�� ������ ���� �ٲ��� Check�Ѵ�. _sec ���� ��ȭ��Ų��. 
		gettimeofday(&now_time, NULL);
		if ( now_time.tv_sec != pre_time.tv_sec ) {
			pre_time.tv_sec = now_time.tv_sec;

			// hund timer value init
			_hund = 0;										

			// sec timer value init
			_sec++;
			if ( _sec >= 60 ) {
				_sec = 0;
				_minute++;

				// minute timer value init
				if ( _minute >= 60 ) {
					_minute++;
				}
			}
		}
		else { 
			_hund++;
		}

		// 100ms ���� ApgMain()�� ȣ���Ͽ� ������� Application�� ����ǵ��� �Ѵ�.
		lib_sleep(0, 30);
		ApgMain();
		
		// Create apg socket
		if ( lib_create_sock() < 0 ) {
			exit(0);
		}

		// send message
		if ( lib_send_msg(LIB_SEND_TYPE_NONE) < 0 ) {
			exit(0);
		}
		lib_sleep(0, 40);

		// receive message and handler message....!!! 
		n_length = lib_recv_msg();
		if ( n_length > 0 ) {
			lib_handler();
		}

		close(client_socket);

		//fprintf(stdout, "%d - %d - %d \n", _minute, _sec, _hund );
		//fflush(stdout);
	}

	return 0;
}


// ----------------------------------------------------------------------------
// POINT DEFINE FUCNTION 
// Description : �Ʒ��� function���� point define�� ���� function ���̴�. 
// 				 Apg app���� Call�Ǹ�, �ڽ��� Point define ���� �ƴϸ� 
// 				 �����Ѵ�. 
//
// Reference code.
// ---------------------------------------------------------------------------- 
// PdefDo2s(pcm, pno++, INIT_RESUME); 
// PdefVo(pcm, pno++, 0.5, 1, 0, 0, 100);       
// PdefJpt1000(pcm, pno++, 3.0, 0, -30, 130);
// PdefDi2s(pcm, pno++);
// PdefVi(pcm, 11, 2.0,  1,   0,  0, 100);  
// PdefCi(pcm, 16, 1.0, 1.25, -20, 0, 100);
// PdefVr(pcm, pno++, 0.1, -100, 150);


void PdefDo2s(byte pcm, byte pno, byte opt)
// ----------------------------------------------------------------------------
// POINT DEFINE DO
{
	int i = 0;
	int n_cnt = 0;
	int n_pnt = 0;
	int n_length = 0;
	unsigned char c_chksum = 0;
	APG_PDEF_FORMAT_T *p_data;

	memset( tx_msg, 0x00, sizeof(tx_msg) );

	// check pcm number
	if ( pcm != gn_id ) 
		return;

	// Create apg socket
	if ( lib_create_sock() < 0 ) {
		exit(0);
	}

	// change type
	gn_sendtype = LIB_SEND_TYPE_PDEF;

	// get data pointer
	n_pnt = 2;
	p_data = (APG_PDEF_FORMAT_T *) &tx_msg[n_pnt];	
	
	// get value
	p_data->c_cmd = LIB_PDEF_REQUEST;
	p_data->c_pcm = pcm;
	p_data->w_pno = pno;
	p_data->f_type = LIB_PDEF_DO;
	p_data->f_hyst = 0.5;
	p_data->f_scale = 1;
	p_data->f_offset = 0;
	p_data->f_min = 0;
	p_data->f_max = 1;
	
	// set total length
	n_length = 32;
	tx_msg[0] = 0x00;
	tx_msg[1] = n_length;

	// calculate total chksum
	c_chksum = 0;
	for ( i = 0; i < n_length - 1; i++ ) {
		c_chksum -= tx_msg[i];
	}
	tx_msg[n_length - 1] = c_chksum;

	// send message
	if( write( client_socket, tx_msg, n_length ) <= 0) {
		fprintf( stdout, "[ERR] Send in %s()\n", __FUNCTION__ );
		fflush(stdout);
		return;
	}	

	lib_sleep(0, 5);

	// receive message and handler message....!!! 
	n_length = lib_recv_msg();
	if ( n_length > 0 ) {
		lib_handler();
	}

	close(client_socket);
}


void PdefVo(byte pcm, byte pno, float f_hyst, float f_scale, float f_offset, float f_min, float f_max)
// ----------------------------------------------------------------------------
// POINT DEFINE VO
{
	int i = 0;
	int n_cnt = 0;
	int n_pnt = 0;
	int n_length = 0;
	unsigned char c_chksum = 0;
	APG_PDEF_FORMAT_T *p_data;

	memset( tx_msg, 0x00, sizeof(tx_msg) );

	// check pcm number
	if ( pcm != gn_id ) 
		return;

	// Create apg socket
	if ( lib_create_sock() < 0 ) {
		exit(0);
	}

	// change type
	gn_sendtype = LIB_SEND_TYPE_PDEF;


	// get data pointer
	n_pnt = 2;
	p_data = (APG_PDEF_FORMAT_T *) &tx_msg[n_pnt];	
	
	// get value
	p_data->c_cmd = LIB_PDEF_REQUEST;
	p_data->c_pcm = pcm;
	p_data->w_pno = pno;
	p_data->f_type = LIB_PDEF_VO;
	p_data->f_hyst = f_hyst;
	p_data->f_scale = f_scale;
	p_data->f_offset = f_offset;
	p_data->f_min = f_min;
	p_data->f_max = f_max;
	
	// set total length
	n_length = 32;
	tx_msg[0] = 0x00;
	tx_msg[1] = n_length;

	// calculate total chksum
	c_chksum = 0;
	for ( i = 0; i < n_length - 1; i++ ) {
		c_chksum -= tx_msg[i];
	}
	tx_msg[n_length - 1] = c_chksum;

	// send message
	if( write( client_socket, tx_msg, n_length ) <= 0) {
		fprintf( stdout, "[ERR] Send in %s()\n", __FUNCTION__ );
		fflush(stdout);
		return;
	}	

	lib_sleep(0, 5);

	// receive message and handler message....!!! 
	n_length = lib_recv_msg();
	if ( n_length > 0 ) {
		lib_handler();
	}

	close(client_socket);
}


void PdefJpt1000(byte pcm, byte pno, float f_hyst, float f_offset, float f_min, float f_max)
// ----------------------------------------------------------------------------
// POINT DEFINE JPT1000
{
	int i = 0;
	int n_cnt = 0;
	int n_pnt = 0;
	int n_length = 0;
	unsigned char c_chksum = 0;
	APG_PDEF_FORMAT_T *p_data;

	memset( tx_msg, 0x00, sizeof(tx_msg) );

	// check pcm number
	if ( pcm != gn_id ) 
		return;

	// Create apg socket
	if ( lib_create_sock() < 0 ) {
		exit(0);
	}

	// change type
	gn_sendtype = LIB_SEND_TYPE_PDEF;


	// get data pointer
	n_pnt = 2;
	p_data = (APG_PDEF_FORMAT_T *) &tx_msg[n_pnt];	
	
	// get value
	p_data->c_cmd = LIB_PDEF_REQUEST;
	p_data->c_pcm = pcm;
	p_data->w_pno = pno;
	p_data->f_type = LIB_PDEF_JPT1000;
	p_data->f_hyst = f_hyst;
	p_data->f_scale = 1;
	p_data->f_offset = f_offset;
	p_data->f_min = f_min;
	p_data->f_max = f_max;
	
	// set total length
	n_length = 32;
	tx_msg[0] = 0x00;
	tx_msg[1] = n_length;

	// calculate total chksum
	c_chksum = 0;
	for ( i = 0; i < n_length - 1; i++ ) {
		c_chksum -= tx_msg[i];
	}
	tx_msg[n_length - 1] = c_chksum;

	// send message
	if( write( client_socket, tx_msg, n_length ) <= 0) {
		fprintf( stdout, "[ERR] Send in %s()\n", __FUNCTION__ );
		fflush(stdout);
		return;
	}	

	lib_sleep(0, 5);

	// receive message and handler message....!!! 
	n_length = lib_recv_msg();
	if ( n_length > 0 ) {
		lib_handler();
	}

	close(client_socket);
}


void PdefDi2s(byte pcm, byte pno)
// ----------------------------------------------------------------------------
// POINT DEFINE DI2S
{
	int i = 0;
	int n_cnt = 0;
	int n_pnt = 0;
	int n_length = 0;
	unsigned char c_chksum = 0;
	APG_PDEF_FORMAT_T *p_data;

	memset( tx_msg, 0x00, sizeof(tx_msg) );

	// check pcm number
	if ( pcm != gn_id ) 
		return;

	// Create apg socket
	if ( lib_create_sock() < 0 ) {
		exit(0);
	}

	// change type
	gn_sendtype = LIB_SEND_TYPE_PDEF;


	// get data pointer
	n_pnt = 2;
	p_data = (APG_PDEF_FORMAT_T *) &tx_msg[n_pnt];	
	
	// get value
	p_data->c_cmd = LIB_PDEF_REQUEST;
	p_data->c_pcm = pcm;
	p_data->w_pno = pno;
	p_data->f_type = LIB_PDEF_DI2S;
	p_data->f_hyst = 0.5;
	p_data->f_scale = 1;
	p_data->f_offset = 0;
	p_data->f_min = 0;
	p_data->f_max = 1;
	
	// set total length
	n_length = 32;
	tx_msg[0] = 0x00;
	tx_msg[1] = n_length;

	// calculate total chksum
	c_chksum = 0;
	for ( i = 0; i < n_length - 1; i++ ) {
		c_chksum -= tx_msg[i];
	}
	tx_msg[n_length - 1] = c_chksum;

	// send message
	if( write( client_socket, tx_msg, n_length ) <= 0) {
		fprintf( stdout, "[ERR] Send in %s()\n", __FUNCTION__ );
		fflush(stdout);
		return;
	}	

	lib_sleep(0, 5);

	// receive message and handler message....!!! 
	n_length = lib_recv_msg();
	if ( n_length > 0 ) {
		lib_handler();
	}

	close(client_socket);
}


void PdefVi(byte pcm, byte pno, float f_hyst, float f_scale, float f_offset, float f_min, float f_max)
// ----------------------------------------------------------------------------
// POINT DEFINE VI
{
	int i = 0;
	int n_cnt = 0;
	int n_pnt = 0;
	int n_length = 0;
	unsigned char c_chksum = 0;
	APG_PDEF_FORMAT_T *p_data;

	memset( tx_msg, 0x00, sizeof(tx_msg) );

	// check pcm number
	if ( pcm != gn_id ) 
		return;

	// Create apg socket
	if ( lib_create_sock() < 0 ) {
		exit(0);
	}

	// change type
	gn_sendtype = LIB_SEND_TYPE_PDEF;


	// get data pointer
	n_pnt = 2;
	p_data = (APG_PDEF_FORMAT_T *) &tx_msg[n_pnt];	
	
	// get value
	p_data->c_cmd = LIB_PDEF_REQUEST;
	p_data->c_pcm = pcm;
	p_data->w_pno = pno;
	p_data->f_type = LIB_PDEF_VI;
	p_data->f_hyst = f_hyst;
	p_data->f_scale = f_scale;
	p_data->f_offset = f_offset;
	p_data->f_min = f_min;
	p_data->f_max = f_max;
	
	// set total length
	n_length = 32;
	tx_msg[0] = 0x00;
	tx_msg[1] = n_length;

	// calculate total chksum
	c_chksum = 0;
	for ( i = 0; i < n_length - 1; i++ ) {
		c_chksum -= tx_msg[i];
	}
	tx_msg[n_length - 1] = c_chksum;

	// send message
	if( write( client_socket, tx_msg, n_length ) <= 0) {
		fprintf( stdout, "[ERR] Send in %s()\n", __FUNCTION__ );
		fflush(stdout);
		return;
	}	

	lib_sleep(0, 5);

	// receive message and handler message....!!! 
	n_length = lib_recv_msg();
	if ( n_length > 0 ) {
		lib_handler();
	}

	close(client_socket);
}


void PdefCi(byte pcm, byte pno, float f_hyst, float f_scale, float f_offset, float f_min, float f_max)
// ----------------------------------------------------------------------------
// POINT DEFINE CI
{
	int i = 0;
	int n_cnt = 0;
	int n_pnt = 0;
	int n_length = 0;
	unsigned char c_chksum = 0;
	APG_PDEF_FORMAT_T *p_data;

	memset( tx_msg, 0x00, sizeof(tx_msg) );

	// check pcm number
	if ( pcm != gn_id ) 
		return;

	// Create apg socket
	if ( lib_create_sock() < 0 ) {
		exit(0);
	}

	// change type
	gn_sendtype = LIB_SEND_TYPE_PDEF;


	// get data pointer
	n_pnt = 2;
	p_data = (APG_PDEF_FORMAT_T *) &tx_msg[n_pnt];	
	
	// get value
	p_data->c_cmd = LIB_PDEF_REQUEST;
	p_data->c_pcm = pcm;
	p_data->w_pno = pno;
	p_data->f_type = LIB_PDEF_CI;
	p_data->f_hyst = f_hyst;
	p_data->f_scale = f_scale;
	p_data->f_offset = f_offset;
	p_data->f_min = f_min;
	p_data->f_max = f_max;
	
	// set total length
	n_length = 32;
	tx_msg[0] = 0x00;
	tx_msg[1] = n_length;

	// calculate total chksum
	c_chksum = 0;
	for ( i = 0; i < n_length - 1; i++ ) {
		c_chksum -= tx_msg[i];
	}
	tx_msg[n_length - 1] = c_chksum;

	// send message
	if( write( client_socket, tx_msg, n_length ) <= 0) {
		fprintf( stdout, "[ERR] Send in %s()\n", __FUNCTION__ );
		fflush(stdout);
		return;
	}	

	lib_sleep(0, 5);

	// receive message and handler message....!!! 
	n_length = lib_recv_msg();
	if ( n_length > 0 ) {
		lib_handler();
	}


	close(client_socket);
}


void PdefVr(byte pcm, byte pno, float f_hyst, float f_min, float f_max)
// ----------------------------------------------------------------------------
// POINT DEFINE VR
{
	int i = 0;
	int n_cnt = 0;
	int n_pnt = 0;
	int n_length = 0;
	unsigned char c_chksum = 0;
	APG_PDEF_FORMAT_T *p_data;

	memset( tx_msg, 0x00, sizeof(tx_msg) );

	// check pcm number
	if ( pcm != gn_id ) 
		return;

	// Create apg socket
	if ( lib_create_sock() < 0 ) {
		exit(0);
	}

	// change type
	gn_sendtype = LIB_SEND_TYPE_PDEF;


	// get data pointer
	n_pnt = 2;
	p_data = (APG_PDEF_FORMAT_T *) &tx_msg[n_pnt];	
	
	// get value
	p_data->c_cmd = LIB_PDEF_REQUEST;
	p_data->c_pcm = pcm;
	p_data->w_pno = pno;
	p_data->f_type = LIB_PDEF_VR;
	p_data->f_hyst = f_hyst;
	p_data->f_scale = 1;
	p_data->f_offset = 0;
	p_data->f_min = f_min;
	p_data->f_max = f_max;
	
	// set total length
	n_length = 32;
	tx_msg[0] = 0x00;
	tx_msg[1] = n_length;

	// calculate total chksum
	c_chksum = 0;
	for ( i = 0; i < n_length - 1; i++ ) {
		c_chksum -= tx_msg[i];
	}
	tx_msg[n_length - 1] = c_chksum;

	// send message
	if( write( client_socket, tx_msg, n_length ) <= 0) {
		fprintf( stdout, "[ERR] Send in %s()\n", __FUNCTION__ );
		fflush(stdout);
		return;
	}	

	lib_sleep(0, 5);

	// receive message and handler message....!!! 
	n_length = lib_recv_msg();
	if ( n_length > 0 ) {
		lib_handler();
	}

	close(client_socket);
}

