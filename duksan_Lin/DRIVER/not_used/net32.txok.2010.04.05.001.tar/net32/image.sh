make clean
make
cp dev_net32.ko /root/AESOP/duksan/
cp dev_net32.ko /root/AESOP/root/
