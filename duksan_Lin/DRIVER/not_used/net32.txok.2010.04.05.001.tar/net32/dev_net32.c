
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/kthread.h>
#include <linux/interrupt.h>
#include <linux/sched.h>

#include <linux/fs.h>          
#include <linux/errno.h>       
#include <linux/types.h>       
#include <linux/fcntl.h>       

#include <asm/uaccess.h>
#include <asm/io.h>

#include <linux/time.h>
#include <linux/timer.h>

#include <linux/netdevice.h>
#include <linux/ip.h>
#include <linux/in.h>

#include <linux/delay.h>
 
#include <asm/system.h>
#include <asm/leds.h>
#include <asm/mach-types.h>

#include <asm/mach/arch.h>
#include <asm/mach/map.h>
#include <asm/mach/irq.h>
#include <asm/arch/fb.h>				// kingseft
#include <asm/hardware.h>
#include <asm/io.h>
#include <asm/irq.h>

#include <asm/arch/regs-timer.h>
#include <asm/arch/regs-irq.h>
#include <asm/mach/time.h>
#include <asm/hardware/clock.h>

#include <asm/arch/regs-serial.h>
#include <asm/arch/regs-gpio.h>
#include "dev_net32.h"

#define  BUFF_SIZE      1024
#define  MAJOR_NUMBER   250

#define NET32_TX_EN		s3c2410_gpio_setpin( S3C2410_GPB5, 1 );
#define NET32_TX_DIS	s3c2410_gpio_setpin( S3C2410_GPB5, 0 );

#define net32addr(reg) (0xf0804000 + (reg))

#define net32_wr_regb(reg, val) \
  do { __raw_writeb(val, net32addr(reg)); } while(0)

#define net32_rd_regb(reg) (__raw_readb(net32addr(reg)))

static unsigned long timer_startval;
static unsigned long timer_usec_ticks;

#define TIMER_USEC_SHIFT 16

/* net32 token message */
typedef struct {
	unsigned char	dest;		  // 0x00, Destination (Rx module)
	unsigned char	cmt;		  // 0x01, Message type
	unsigned char	len;		  // 0x02, Message length (9)
	unsigned char	src;		  // 0x03, Source (Tx module)
	unsigned char	tdest;			// 0x04, Tocken destination module
	unsigned char	chksum; 		// 0x05, Chksum (2's)
}	TockenMsg;
//static TockenMsg *g_Token;

typedef struct {
	int MyId;
	unsigned long Cnt2ms;
	unsigned long Cnt10ms;
	TockenMsg *g_Token;
	//void (*InitNet32)(void);
	int  (*SerialOut)(unsigned char *s, int length);
	void  (*CreateToken)(unsigned char *p);
	//void (*TokenTx)(int iId, int iMyId);
	//int (*MsgRx)(const char *s);
} __attribute__ ((packed)) NET32_INFO;
static NET32_INFO *g_Net32Info;


static char *buffer  = NULL;







/**************************************************************************/
static int *Net32SerialOut(unsigned char *buf, int length)
/**************************************************************************/
{
	int i = 0;
	unsigned long loopCnt = 0;
	
	//printk("length = %d\n", length);
	
	//printk("NET32 TX Enable\n");
	NET32_TX_EN

	//#define S3C2410_UTRSTAT_TXE	  (1<<2)
	//#define S3C2410_UTRSTAT_TXFE	  (1<<1)
	//#define S3C2410_UTRSTAT_RXDR	  (1<<0)	
	/* try and drain the buffer... */
	for (i = 0; i < length; i++) {
		//if (rd_regl(port, S3C2410_UFSTAT) & ourport->info->tx_fifofull)
		//	break;
		
		//wr_regb(port, S3C2410_UTXH, xmit->buf[xmit->tail]);
		net32_wr_regb(S3C2410_UTXH, buf[i]);
		
		while(1) {
			if ( net32_rd_regb(S3C2410_UTRSTAT) &  S3C2410_UTRSTAT_TXE )
				break;
			loopCnt++;
		}
	}

	//printk("NET32 TX Disable\n");
	NET32_TX_DIS	
	return 0;
}

/**************************************************************************/
static void CreateTokenMessage(unsigned char *buf)
/**************************************************************************/
{
	int i = 0;
	TockenMsg *p = (TockenMsg *) buf;
	
    p->dest   = 0xff;
    p->cmt    = 0x80;		//CMT_TOCKEN    0x80
    p->len    = 5;
    p->src    = iMyId;
    p->tdest  = iId;
    p->chksum = 0;

    for ( i = 0; i < 5; i++ )
        p->chksum -= token[i];		
	
	return sizeof(TockenMsg);
}


/* timer3_2ms_isr
 * 
 * 
 */
/****************************************************************************/ 
static irqreturn_t 
timer3_2ms_isr(int irq, void *dev_id, struct pt_regs *regs)
/****************************************************************************/
{
	NET32_INFO *pInfo = (NET32_INFO *)dev_id;
	unsigned char msg[12];	
	int length = 0;
	
	pInfo->Cnt2ms++;
	if ( !(pInfo->Cnt2ms%5) ) {
		pInfo->Cnt10ms++;
		
		length = pInfo->CreateToken(msg);
		if (pInfo->SerialOut != NULL)	// need for protect linux panic
			pInfo->SerialOut(msg, length);
	}

    return IRQ_HANDLED;
}

/* timer_mask_usec_ticks
 *
 * given a clock and divisor, make the value to pass into timer_ticks_to_usec
 * to scale the ticks into usecs
*/
/****************************************************************************/
static inline unsigned long
timer_mask_usec_ticks(unsigned long scaler, unsigned long pclk)
/****************************************************************************/
{
	unsigned long den = pclk / 1000;

	return ((1000 << TIMER_USEC_SHIFT) * scaler + (den >> 1)) / den;
}

/* timer_ticks_to_usec
 *
 * convert timer ticks to usec.
*/
/****************************************************************************/
static inline unsigned long 
timer_ticks_to_usec(unsigned long ticks)
/****************************************************************************/
{
	unsigned long res;

	res = ticks * timer_usec_ticks;
	res += 1 << (TIMER_USEC_SHIFT - 4);	/* round up slightly */

	return res >> TIMER_USEC_SHIFT;
}

/* timer3_init
 *
 * timer3�� 2ms�� �����Ѵ�. 
 * prescale ���� ������ ���� timer2�� ����Ǿ� �ֱ� ������ �����Ѵ�.
 */
/****************************************************************************/
static void timer3_init(void)
/****************************************************************************/
{
	unsigned long tcon;
	unsigned long tcnt;
	unsigned long tcfg1;
	unsigned long tcfg0;
	unsigned long pclk;
	struct clk *clk;

	tcnt = 0xffff;  /* default value for tcnt */

	/* read the current timer configuration bits */

	tcon = __raw_readl(S3C2410_TCON);
	tcfg1 = __raw_readl(S3C2410_TCFG1);
	tcfg0 = __raw_readl(S3C2410_TCFG0);

	if (machine_is_bast() || machine_is_vr1000()) {
		/* timer is at 12MHz, scaler is 1 */
		timer_usec_ticks = timer_mask_usec_ticks(1, 12000000);
		tcnt = 12000000 / HZ;

		tcfg1 &= ~S3C2410_TCFG1_MUX4_MASK;
		tcfg1 |= S3C2410_TCFG1_MUX4_TCLK1;
	} else {

		/* for the h1940 (and others), we use the pclk from the core
		 * to generate the timer values. since values around 50 to
		 * 70MHz are not values we can directly generate the timer
		 * value from, we need to pre-scale and divide before using it.
		 *
		 * for instance, using 50.7MHz and dividing by 6 gives 8.45MHz
		 * (8.45 ticks per usec)
		 *
		 */

		/* this is used as default if no other timer can be found */
		clk = clk_get(NULL, "timers");
		if (IS_ERR(clk))
			panic("failed to get clock for system timer");

		clk_use(clk);
		clk_enable(clk);

		pclk = clk_get_rate(clk);
		//printk("pclk = %ld\n", pclk);
	
		/* configure clock tick */
		timer_usec_ticks = timer_mask_usec_ticks(6, pclk);
		
		tcfg1 &= ~S3C2410_TCFG1_MUX3_MASK;
		tcfg1 |= S3C2410_TCFG1_MUX3_DIV2;		

		tcfg0 &= ~S3C2410_TCFG_PRESCALER1_MASK;
		tcfg0 |= ((6 - 1) / 2)  << S3C2410_TCFG_PRESCALER1_SHIFT;
		
		tcnt = 16900;	// 16900 = 8.45(ticks per usec) * 2000(usec) = 2ms
		/*
		timer_usec_ticks = timer_mask_usec_ticks(6, pclk);
		
		tcfg1 &= ~S3C2410_TCFG1_MUX3_MASK;
		tcfg1 |= S3C2410_TCFG1_MUX3_DIV8;		

		tcfg0 &= ~S3C2410_TCFG_PRESCALER1_MASK;
		tcfg0 |= ((6 - 1) / 8)  << S3C2410_TCFG_PRESCALER1_SHIFT;

		tcnt = 4225 + 10;	// 4225 = 2.1125(divided Mhz) * 2000 usec = 2ms
		*/		
	}

	/* timers reload after counting zero, so reduce the count by 1 */
	tcnt--;

	/* check to see if timer is within 16bit range... */
	if (tcnt > 0xffff) {
		panic("setup_timer: HZ is too small, cannot configure timer!");
		return;
	}

	__raw_writel(tcfg1, S3C2410_TCFG1);
	__raw_writel(tcfg0, S3C2410_TCFG0);

	timer_startval = tcnt;
	__raw_writel(tcnt, S3C2410_TCNTB(3));

	/* ensure timer is stopped... */
	tcon &= ~(7<<16);
	tcon |= S3C2410_TCON_T3RELOAD;
	tcon |= S3C2410_TCON_T3MANUALUPD;

	__raw_writel(tcon, S3C2410_TCON);
	__raw_writel(tcnt, S3C2410_TCNTB(3));
	__raw_writel(tcnt, S3C2410_TCMPB(3));

	/* start the timer running */
	tcon |= S3C2410_TCON_T3START;
	tcon &= ~S3C2410_TCON_T3MANUALUPD;
	__raw_writel(tcon, S3C2410_TCON);

	printk("timer setting \ntcon=%08lx, \ntcnt %04lx, \ntcfg %08lx, %08lx, \nusec %08lx\n",
	       tcon, tcnt, tcfg0, tcfg1, timer_usec_ticks);
}




/**************************************************************************/
static int Net32Open( struct inode *inode, struct file *filp ) 
/**************************************************************************/
{
	unsigned char msg[10] = "0123456789";
	printk( "[Net32] opened\n" );
	
	Net32SerialOut(msg, 10);
	return 0;
}

/**************************************************************************/
static int Net32Release( struct inode *inode, struct file *filp )
/**************************************************************************/
{
	printk( "[Net32] released\n" );
	return 0;
}

/**************************************************************************/
static ssize_t Net32WriteData( 
	struct file *filp, 
	const char *buf, 
	size_t count, 
	loff_t *f_pos )
/**************************************************************************/	
{
   return 0;
}

/**************************************************************************/
static ssize_t Net32ReadData( 
	struct file *filp, 
	char *buf, 
	size_t count, 
	loff_t *f_pos )
/**************************************************************************/	
{
	return 0;
}


static struct file_operations vd_fops = {
	.read = Net32ReadData,		// Not use.
	.write = Net32WriteData,		// Not use.
	.open = Net32Open,
	.release = Net32Release
};

/**************************************************************************/
int __init Net32_Init( void )
/**************************************************************************/
{
	// net32 serial out test code
	//unsigned char msg[10] = "0123456789";	
	//Net32SerialOut(msg, 10);	

	register_chrdev( MAJOR_NUMBER, "virtual_buffer", &vd_fops );
	buffer = (char*) kmalloc( BUFF_SIZE, GFP_KERNEL );
	memset( buffer, 0, BUFF_SIZE);
	
	g_Net32Info = (NET32_INFO *) kmalloc( sizeof(NET32_INFO), GFP_KERNEL );;
	memset( g_Net32Info, 0, sizeof(NET32_INFO));

	g_Net32Info->SerialOut = (int *)Net32SerialOut;
	g_Net32Info->CreateToken = (void *)CreateTokenMessage;
	
	timer3_init();	// 2ms timer
    if( request_irq( 
    		IRQ_TIMER3, 
    		timer3_2ms_isr, 
    		SA_INTERRUPT, 
    		"NET32", 
    		g_Net32Info ) ) {
        printk( "[NET32]: IRQ_TIMER3 unable to get IRQ %dn", IRQ_TIMER3 );
        return 0;
    }
    else {
    	printk( "[NET32]: IRQ_TIMER3 enable to get IRQ %dn", IRQ_TIMER3 );
	}


	printk( "[Net32] initialized\n");

	return 0;
}

/**************************************************************************/
void __exit Net32_Exit( void )
/**************************************************************************/
{
	free_irq( IRQ_TIMER3, NULL);
	
	unregister_chrdev( MAJOR_NUMBER, "NET32" );
	kfree( buffer );
	kfree( g_Net32Info );
	printk( "[Net32] exited\n");
}

module_init( Net32_Init );
module_exit( Net32_Exit );

MODULE_LICENSE( "GPL" );
