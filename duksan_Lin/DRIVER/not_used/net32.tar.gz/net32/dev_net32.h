/*-----------------------------------------------------------------------------
  files 	: run_led.h
  author	: jong2ry@imecasys.com
  date 		: 2010-01-27
-------------------------------------------------------------------------------*/
#ifndef _DEV_NET32_H_
#define _DEV_NET32_H_

/* define -------------------------------------------------------------------*/
#define		NET32_DEF			220
#define		DEV_NAME			"S3C2410 Net32 Module ver 1.00"
#define 	VERSION_STR 		"Ver 1.00"



#endif  // _DEV_LED_H_


