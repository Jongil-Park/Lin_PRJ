make clean
make
cp prompt /root/AESOP/duksan/BIN

