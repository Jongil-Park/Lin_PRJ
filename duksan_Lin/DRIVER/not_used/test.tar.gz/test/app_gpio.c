
// ������   : 
//
// ��  ��   : 
//             
//------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/poll.h>

#include "dev_gpio.h"

#define VERSION_STR "Ver 1.00"

int dev_fd;


int	dev_open( char *fname, unsigned char major, unsigned char minor )
{
	int	dev;
	
	dev = open( fname, O_RDWR|O_NDELAY );
	if (dev == -1 )
	{
		mknod( fname, (S_IRWXU|S_IRWXG|S_IFCHR), (major<<8)|(minor) );
		
		dev = open( fname, O_RDWR|O_NDELAY );
		if (dev == -1 )
		{
			printf( " Device OPEN FAIL %s\n", fname );
			return -1;
		}
	}
        
	return dev;
}


int main( int argc, char **argv )
{       
	int no = atoi(argv[2]);
	int val = atoi(argv[3]);
	dip_sw_info dip;

	//printf( "\n  Program Ver %s  %s %s\n", VERSION_STR, __DATE__, __TIME__ );

	if ( argc < 3 )
	{
		printf(" argc Error = %d\n", argc);
		return 0;
	}
	
	dev_fd = dev_open("/dev/gpio", GPIO_MAJOR_DEF, 0 );

/*
	ioctl( dev_fd, IOCTL_GPIO_A_ON, 1 );
	ioctl( dev_fd, IOCTL_GPIO_B_ON, 2 );
	ioctl( dev_fd, IOCTL_GPIO_C_ON, 3 );
	ioctl( dev_fd, IOCTL_GPIO_D_ON, 4 );

	ioctl( dev_fd, IOCTL_GPIO_A_OFF, 1 );
	ioctl( dev_fd, IOCTL_GPIO_B_OFF, 2 );
	ioctl( dev_fd, IOCTL_GPIO_C_OFF, 3 );
	ioctl( dev_fd, IOCTL_GPIO_D_OFF, 4 );
*/	
	if (val> 0)
	{
		switch ( argv[1][0] )
		{
			case 'a' : ioctl( dev_fd, IOCTL_GPIO_A_ON, no ); break;
			case 'b' : ioctl( dev_fd, IOCTL_GPIO_B_ON, no ); break;
			case 'c' : ioctl( dev_fd, IOCTL_GPIO_C_ON, no ); break;
			case 'd' : ioctl( dev_fd, IOCTL_GPIO_D_ON, no ); break;
			case 'e' : ioctl( dev_fd, IOCTL_GPIO_E_ON, no ); break;
			case 'f' : ioctl( dev_fd, IOCTL_GPIO_F_ON, no ); break;
			case 'g' : ioctl( dev_fd, IOCTL_GPIO_G_ON, no ); break;
			case 'h' : ioctl( dev_fd, IOCTL_GPIO_H_ON, no ); break;
			case 'r' : 
				ioctl( dev_fd, IOCTL_GET_DIP_SWITCH, &dip ); 
				//printf("DIP = %d\n", dip.info);	
				//printf("size = %d\n", dip.size);
				break;
			default	 : 	break;					
		}
	}
	else
	{
		switch ( argv[1][0] )
		{
			case 'a' : ioctl( dev_fd, IOCTL_GPIO_A_OFF, no ); break;
			case 'b' : ioctl( dev_fd, IOCTL_GPIO_B_OFF, no ); break;
			case 'c' : ioctl( dev_fd, IOCTL_GPIO_C_OFF, no ); break;
			case 'd' : ioctl( dev_fd, IOCTL_GPIO_D_OFF, no ); break;
			case 'e' : ioctl( dev_fd, IOCTL_GPIO_E_OFF, no ); break;
			case 'f' : ioctl( dev_fd, IOCTL_GPIO_F_OFF, no ); break;
			case 'g' : ioctl( dev_fd, IOCTL_GPIO_G_OFF, no ); break;
			case 'h' : ioctl( dev_fd, IOCTL_GPIO_H_OFF, no ); break;
			default	 : 	break;					
		}	
	}

	
	close( dev_fd );

	return 0;
}



