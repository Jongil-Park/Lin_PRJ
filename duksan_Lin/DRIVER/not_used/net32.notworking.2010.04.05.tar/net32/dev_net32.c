
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/kthread.h>
#include <linux/interrupt.h>
#include <linux/sched.h>

#include <linux/fs.h>          
#include <linux/errno.h>       
#include <linux/types.h>       
#include <linux/fcntl.h>       

#include <asm/uaccess.h>
#include <asm/io.h>

#include <linux/time.h>
#include <linux/timer.h>

#include <linux/netdevice.h>
#include <linux/ip.h>
#include <linux/in.h>

#include <linux/delay.h>
 
#include <asm/system.h>
#include <asm/leds.h>
#include <asm/mach-types.h>

#include <asm/mach/arch.h>
#include <asm/mach/map.h>
#include <asm/mach/irq.h>
#include <asm/arch/fb.h>				// kingseft
#include <asm/hardware.h>
#include <asm/io.h>
#include <asm/irq.h>

#include <asm/arch/regs-timer.h>
#include <asm/arch/regs-irq.h>
#include <asm/mach/time.h>
#include <asm/hardware/clock.h>

#include <asm/arch/regs-serial.h>
#include <asm/arch/regs-gpio.h>
#include "dev_net32.h"

#define CMT_TOCKEN		0x80


/* net32 token message */
typedef struct {
	unsigned char	dest;		  // 0x00, Destination (Rx module)
	unsigned char	cmt;		  // 0x01, Message type
	unsigned char	len;		  // 0x02, Message length (9)
	unsigned char	src;		  // 0x03, Source (Tx module)
	unsigned char	tdest;			// 0x04, Tocken destination module
	unsigned char	chksum; 		// 0x05, Chksum (2's)
} __attribute__ ((packed)) TockenMsg;
TockenMsg MyToken;



//DEL static int major  = NET32_DEF;

struct kthread_t {
	struct task_struct *thread;
	int running;
};

static struct kthread_t *kthread = NULL;

static unsigned long timer_startval;
static unsigned long timer_usec_ticks;

#define TIMER_USEC_SHIFT 16

typedef struct {
	int MyId;
	unsigned long timer3Count;
	unsigned long timer2Count;
	unsigned long Cnt2ms;
	unsigned long Cnt10ms;
	void (*InitNet32)(void);
	void (*MsgTx)(const char *s, int length);
	void (*TokenTx)(int iId, int iMyId);
	int (*MsgRx)(const char *s);
} __attribute__ ((packed)) TIMER_COUNT_INFO;


#define NET32_TX_EN		s3c2410_gpio_setpin( S3C2410_GPB5, 1 );
#define NET32_TX_DIS	s3c2410_gpio_setpin( S3C2410_GPB5, 0 );

#define UART1DEVICE "/dev/s3c2410_serial1"

extern void s3c2410_Uart1Net32Init(void);
extern void s3c2410_uartTest(unsigned char *p, int length);
extern int 	s3c2410_uartGetTest(void);
extern void s3c2410_Uart1TokenTx(int iId, int iMyId);


void SendTokenTx(void *dev_id, int iId, int iMyId)
{
	int i = 0;
	int iLength = sizeof(MyToken);
	TIMER_COUNT_INFO *pInfo = (TIMER_COUNT_INFO *)dev_id;
		
    MyToken.dest   = 0xff;
    MyToken.cmt    = CMT_TOCKEN;		//CMT_TOCKEN 0x80
    MyToken.len    = 5;
    MyToken.src    = iMyId;
    MyToken.tdest  = iId;
    MyToken.chksum = 0;	

    for ( i = 0; i < 5; i++ )
        MyToken.chksum -= *( (unsigned char *)&MyToken + i );	
	
	pInfo->MsgTx( (unsigned char *)&MyToken, iLength); 	
}

/* timer3_2ms_isr
 * 
 * 
 */
/****************************************************************************/ 
static irqreturn_t 
timer3_2ms_isr(int irq, void *dev_id, struct pt_regs *regs)
/****************************************************************************/
{
	TIMER_COUNT_INFO *p_Info = (TIMER_COUNT_INFO *)dev_id;
	
	p_Info->Cnt2ms++;
	if ( !(p_Info->Cnt2ms%5) ) {
		p_Info->Cnt10ms++;
		//SendTokenTx(dev_id, 1, 0);
	}

    return IRQ_HANDLED;
}

#if 0
/* timer2_10ms_isr
 * 
 * 
 */
static irqreturn_t 
timer2_10ms_isr(int irq, void *dev_id, struct pt_regs *regs)
{
	TIMER_COUNT_INFO *p_Info;
	
	p_Info = (TIMER_COUNT_INFO *)dev_id;
	p_Info->timer2Count++;

    return IRQ_HANDLED;
}
#endif 

/* timer_mask_usec_ticks
 *
 * given a clock and divisor, make the value to pass into timer_ticks_to_usec
 * to scale the ticks into usecs
*/
/****************************************************************************/
static inline unsigned long
timer_mask_usec_ticks(unsigned long scaler, unsigned long pclk)
/****************************************************************************/
{
	unsigned long den = pclk / 1000;

	return ((1000 << TIMER_USEC_SHIFT) * scaler + (den >> 1)) / den;
}

/* timer_ticks_to_usec
 *
 * convert timer ticks to usec.
*/
/****************************************************************************/
static inline unsigned long 
timer_ticks_to_usec(unsigned long ticks)
/****************************************************************************/
{
	unsigned long res;

	res = ticks * timer_usec_ticks;
	res += 1 << (TIMER_USEC_SHIFT - 4);	/* round up slightly */

	return res >> TIMER_USEC_SHIFT;
}


#if 0
/* timer2_init
 *
 * timer2�� 10ms�� �����Ѵ�. 
 * prescale ���� ������ ���� timer3�� ����Ǿ� �ֱ� ������ �����Ѵ�.
 */
static void 
timer2_init(void)
{
	unsigned long tcon;
	unsigned long tcnt;
	unsigned long tcfg1;
	unsigned long tcfg0;
	unsigned long pclk;
	struct clk *clk;

	tcnt = 0xffff;  /* default value for tcnt */

	/* read the current timer configuration bits */

	tcon = __raw_readl(S3C2410_TCON);
	tcfg1 = __raw_readl(S3C2410_TCFG1);
	tcfg0 = __raw_readl(S3C2410_TCFG0);

	if (machine_is_bast() || machine_is_vr1000()) {
		/* timer is at 12MHz, scaler is 1 */
		timer_usec_ticks = timer_mask_usec_ticks(1, 12000000);
		tcnt = 12000000 / HZ;

		tcfg1 &= ~S3C2410_TCFG1_MUX4_MASK;
		tcfg1 |= S3C2410_TCFG1_MUX4_TCLK1;
	} else {

		/* for the h1940 (and others), we use the pclk from the core
		 * to generate the timer values. since values around 50 to
		 * 70MHz are not values we can directly generate the timer
		 * value from, we need to pre-scale and divide before using it.
		 *
		 * for instance, using 50.7MHz and dividing by 6 gives 8.45MHz
		 * (8.45 ticks per usec)
		 *
		 * for instance, using 50.7MHz and dividing by 6 gives 8.45MHz
		 * (8.45 ticks per usec)		 
		 */

		/* this is used as default if no other timer can be found */

		clk = clk_get(NULL, "timers");
		if (IS_ERR(clk))
			panic("failed to get clock for system timer");

		clk_use(clk);
		clk_enable(clk);

		pclk = clk_get_rate(clk);
		
		printk("pclk = %ld\n", pclk);
	
		/* configure clock tick */

/*
* priod = (prescaler value + 1) * (divider value) * buffer count / PCLK = 10 ms
*
* e.g.; PCLK = 50 Mhz
* 10 ms = (15 + 1) * 2 * 15625 / (50000 * 1000)
* 15626 = 10 ms * (50000 * 1000) / 2 / (15 + 1)
*
* priod = (prescaler value + 1) * (divider value) * buffer count / PCLK = 2 ms
* e.g.; PCLK = 50 Mhz
* 2 ms = (0 + 1) * 2 * 15625 / (50000 * 1000)
* 15626 = 2 ms * (50000 * 1000) / 2 / (0 + 1)
*
*/
#if 0
		timer_usec_ticks = timer_mask_usec_ticks(6, pclk);

		tcfg1 &= ~S3C2410_TCFG1_MUX3_MASK;
		tcfg1 |= S3C2410_TCFG1_MUX3_DIV2;

		tcfg0 &= ~S3C2410_TCFG_PRESCALER1_MASK;
		tcfg0 |= ((6 - 1) / 2) << S3C2410_TCFG_PRESCALER1_SHIFT;

		tcnt = (pclk / 6) / HZ;
#else		
		timer_usec_ticks = timer_mask_usec_ticks(6, pclk);
		
		tcfg1 &= ~S3C2410_TCFG1_MUX2_MASK;
		tcfg1 |= S3C2410_TCFG1_MUX2_DIV8;		

		tcfg0 &= ~S3C2410_TCFG_PRESCALER1_MASK;
		tcfg0 |= ((6 - 1) / 8)  << S3C2410_TCFG_PRESCALER1_SHIFT;

		tcnt = 21125 + 100;	// 21125 = 2.1125(divided Mhz) * 10000 usec = 2ms
#endif		
	}

	/* timers reload after counting zero, so reduce the count by 1 */
	tcnt--;

	/* check to see if timer is within 16bit range... */
	if (tcnt > 0xffff) {
		panic("setup_timer: HZ is too small, cannot configure timer!");
		return;
	}

	__raw_writel(tcfg1, S3C2410_TCFG1);
	__raw_writel(tcfg0, S3C2410_TCFG0);

	timer_startval = tcnt;
	__raw_writel(tcnt, S3C2410_TCNTB(2));

	/* ensure timer is stopped... */
	tcon &= ~(7<<12);
	tcon |= S3C2410_TCON_T2RELOAD;
	tcon |= S3C2410_TCON_T2MANUALUPD;

	__raw_writel(tcon, S3C2410_TCON);
	__raw_writel(tcnt, S3C2410_TCNTB(2));
	__raw_writel(tcnt, S3C2410_TCMPB(2));

	/* start the timer running */
	tcon |= S3C2410_TCON_T2START;
	tcon &= ~S3C2410_TCON_T2MANUALUPD;
	__raw_writel(tcon, S3C2410_TCON);

	printk("timer2 setting \ntcon=%08lx, \ntcnt %04lx, \ntcfg %08lx, %08lx, \nusec %08lx\n",
	       tcon, tcnt, tcfg0, tcfg1, timer_usec_ticks);
}
#endif

/* timer3_init
 *
 * timer3�� 2ms�� �����Ѵ�. 
 * prescale ���� ������ ���� timer2�� ����Ǿ� �ֱ� ������ �����Ѵ�.
 */
/****************************************************************************/
static void timer3_init(void)
/****************************************************************************/
{
	unsigned long tcon;
	unsigned long tcnt;
	unsigned long tcfg1;
	unsigned long tcfg0;
	unsigned long pclk;
	struct clk *clk;

	tcnt = 0xffff;  /* default value for tcnt */

	/* read the current timer configuration bits */

	tcon = __raw_readl(S3C2410_TCON);
	tcfg1 = __raw_readl(S3C2410_TCFG1);
	tcfg0 = __raw_readl(S3C2410_TCFG0);

	if (machine_is_bast() || machine_is_vr1000()) {
		/* timer is at 12MHz, scaler is 1 */
		timer_usec_ticks = timer_mask_usec_ticks(1, 12000000);
		tcnt = 12000000 / HZ;

		tcfg1 &= ~S3C2410_TCFG1_MUX4_MASK;
		tcfg1 |= S3C2410_TCFG1_MUX4_TCLK1;
	} else {

		/* for the h1940 (and others), we use the pclk from the core
		 * to generate the timer values. since values around 50 to
		 * 70MHz are not values we can directly generate the timer
		 * value from, we need to pre-scale and divide before using it.
		 *
		 * for instance, using 50.7MHz and dividing by 6 gives 8.45MHz
		 * (8.45 ticks per usec)
		 *
		 */

		/* this is used as default if no other timer can be found */
		clk = clk_get(NULL, "timers");
		if (IS_ERR(clk))
			panic("failed to get clock for system timer");

		clk_use(clk);
		clk_enable(clk);

		pclk = clk_get_rate(clk);
		//printk("pclk = %ld\n", pclk);
	
		/* configure clock tick */
		timer_usec_ticks = timer_mask_usec_ticks(6, pclk);
		
		tcfg1 &= ~S3C2410_TCFG1_MUX3_MASK;
		tcfg1 |= S3C2410_TCFG1_MUX3_DIV2;		

		tcfg0 &= ~S3C2410_TCFG_PRESCALER1_MASK;
		tcfg0 |= ((6 - 1) / 2)  << S3C2410_TCFG_PRESCALER1_SHIFT;
		
		tcnt = 16900;	// 16900 = 8.45(ticks per usec) * 2000(usec) = 2ms
		/*
		timer_usec_ticks = timer_mask_usec_ticks(6, pclk);
		
		tcfg1 &= ~S3C2410_TCFG1_MUX3_MASK;
		tcfg1 |= S3C2410_TCFG1_MUX3_DIV8;		

		tcfg0 &= ~S3C2410_TCFG_PRESCALER1_MASK;
		tcfg0 |= ((6 - 1) / 8)  << S3C2410_TCFG_PRESCALER1_SHIFT;

		tcnt = 4225 + 10;	// 4225 = 2.1125(divided Mhz) * 2000 usec = 2ms
		*/		
	}

	/* timers reload after counting zero, so reduce the count by 1 */
	tcnt--;

	/* check to see if timer is within 16bit range... */
	if (tcnt > 0xffff) {
		panic("setup_timer: HZ is too small, cannot configure timer!");
		return;
	}

	__raw_writel(tcfg1, S3C2410_TCFG1);
	__raw_writel(tcfg0, S3C2410_TCFG0);

	timer_startval = tcnt;
	__raw_writel(tcnt, S3C2410_TCNTB(3));

	/* ensure timer is stopped... */
	tcon &= ~(7<<16);
	tcon |= S3C2410_TCON_T3RELOAD;
	tcon |= S3C2410_TCON_T3MANUALUPD;

	__raw_writel(tcon, S3C2410_TCON);
	__raw_writel(tcnt, S3C2410_TCNTB(3));
	__raw_writel(tcnt, S3C2410_TCMPB(3));

	/* start the timer running */
	tcon |= S3C2410_TCON_T3START;
	tcon &= ~S3C2410_TCON_T3MANUALUPD;
	__raw_writel(tcon, S3C2410_TCON);

	printk("timer setting \ntcon=%08lx, \ntcnt %04lx, \ntcfg %08lx, %08lx, \nusec %08lx\n",
	       tcon, tcnt, tcfg0, tcfg1, timer_usec_ticks);
}

#if 0
static dbg_timer(TIMER_COUNT_INFO *p_Info)
{
	unsigned long ul_PreLocTimer3Count = 0;
    unsigned long ul_LocTimer3Count = 0;
	unsigned long ul_PreLocTimer2Count = 0;
    unsigned long ul_LocTimer2Count = 0;

	/* 1�ʿ� �߻��ϴ� Timer2 ���� Ȯ���Ѵ�. */
	ul_LocTimer2Count = p_Info->timer2Count;
	printk("Loop timer2Count = %ld (%ld)!\n", 
		ul_LocTimer2Count, 
		(ul_LocTimer2Count - ul_PreLocTimer2Count));
	ul_PreLocTimer2Count = ul_LocTimer2Count;

	/* 1�ʿ� �߻��ϴ� Timer3 ���� Ȯ���Ѵ�. */
	ul_LocTimer3Count = p_Info->timer3Count;
	printk("Loop timer3Count = %ld (%ld)!\n", 
		ul_LocTimer3Count, 
		(ul_LocTimer3Count - ul_PreLocTimer3Count));
	ul_PreLocTimer3Count = ul_LocTimer3Count;
	printk("\n");     
}
#endif

/*================================================================
 * 2010.03.31 jong2ry
 * net32 kernel thread.
 */
/****************************************************************************/
static void net32td(void *args)
/****************************************************************************/
{
    TIMER_COUNT_INFO *pInfo = (TIMER_COUNT_INFO *)args;
	//unsigned long ul_PreLocTimer3Count = 0;
    //unsigned long ul_LocTimer3Count = 0;
	//unsigned long ul_PreLocTimer2Count = 0;
    //unsigned long ul_LocTimer2Count = 0;	
	int iTestVal = 0;
	unsigned char chTestMsg[10] = "abcdefghij";
	int fd;

	mm_segment_t old_fs = get_fs();
	set_fs(KERNEL_DS);        
        
    /* kernel thread initialization */
    printk("[NET32]: kernel thread initialization\n");
    lock_kernel();
    current->flags |= PF_NOFREEZE;

    /* daemonize (take care with signals, after daemonize() they are disabled) */
    printk("[NET32]: daemonize\n");
    daemonize(DEV_NAME);
    allow_signal(SIGKILL);
    unlock_kernel();
    kthread->running = 1;

	//pInfo->InitNet32();

	
	fd = sys_open("/dev/s3c2410_serial1", O_RDWR | O_NOCTTY | O_NONBLOCK, 0);
	if (fd >= 0) {
		printk("[NET32]: %s Open %d\n", UART1DEVICE, fd);
	}
	else {
		printk("Open Error\n");
		return;
	}
		
	
	for(;;)
	{
		#if 0
		/* 1�ʿ� �߻��ϴ� Timer2 ���� Ȯ���Ѵ�. */
		ul_LocTimer2Count = pInfo->Cnt10ms;
		printk("Loop timer2Count = %ld (%ld)!\n", 
			ul_LocTimer2Count, 
			(ul_LocTimer2Count - ul_PreLocTimer2Count));
		ul_PreLocTimer2Count = ul_LocTimer2Count;
	
		/* 1�ʿ� �߻��ϴ� Timer3 ���� Ȯ���Ѵ�. */
		ul_LocTimer3Count = pInfo->Cnt2ms;
		printk("Loop timer3Count = %ld (%ld)!\n", 
			ul_LocTimer3Count, 
			(ul_LocTimer3Count - ul_PreLocTimer3Count));
		ul_PreLocTimer3Count = ul_LocTimer3Count;
		printk("\n");
		#endif
		
		//s3c2410_uartTest(chTestMsg, sizeof(chTestMsg));
		
		//iTestVal = s3c2410_uartGetTest();
		//printk("iTestVal = %d\n", iTestVal);
		
		set_current_state(TASK_INTERRUPTIBLE);
		schedule_timeout(1*HZ);		
	}
}

/*================================================================ 
 * 2010.03.31 jong2ry
 * net32 kernel_thread�� �����ϰ� ����̹��� ����Ѵ�.
 */
static __init int net32_init(void)
{
    TIMER_COUNT_INFO *pInfo;

	//kmalloc initialize    
    pInfo = kmalloc(sizeof(TIMER_COUNT_INFO), GFP_KERNEL);
    memset(pInfo, 0x00, sizeof(TIMER_COUNT_INFO));
    kthread = kmalloc(sizeof(struct kthread_t), GFP_KERNEL);
    memset(kthread, 0, sizeof(struct kthread_t));

	//function pointer initilaize
	pInfo->InitNet32 = (void *)s3c2410_Uart1Net32Init;
	pInfo->TokenTx = (void *)s3c2410_Uart1TokenTx;
	pInfo->MsgTx = (void *)s3c2410_uartTest;
	pInfo->MsgRx = (int *)s3c2410_uartGetTest;
	
	// create kernel thread
    kthread->thread = kthread_run((void *)net32td, pInfo, DEV_NAME);
    if ( IS_ERR(kthread->thread) ) {
		printk("[NET32]: unable to start kernel thread\n");
		kfree(kthread);
		kthread = NULL;
		//return -ENOMEM;
		return 0;
    }

	// register timer2, timer3 interrupt
	// timer3�� 2ms�� �����ϱ� ������ timer3�� �̿��ؼ� 
	// 10ms�� ������ �Ϸ��� ��.
	//TMP DEL timer2_init();	// 10ms
    //TMP DEL if( request_irq( IRQ_TIMER2, timer2_10ms_isr, SA_INTERRUPT, "PXA-270 Timer#2", pInfo ) ) {
    //TMP DEL    printk( "[NET32]: IRQ_TIMER3 unable to get IRQ %dn", IRQ_TIMER3 );
    //TMP DEL    return 0;
    //TMP DEL }
    
	timer3_init();	// 2ms
    if( request_irq( IRQ_TIMER3, timer3_2ms_isr, SA_INTERRUPT, "PXA-270 Timer#3", pInfo ) ) {
        printk( "[NET32]: IRQ_TIMER3 unable to get IRQ %dn", IRQ_TIMER3 );
        return 0;
    }
    
    return 0;
}

/*================================================================
 * 2010.03.31 jong2ry
 * net32 kernel_thread�� �����ϰ� ����̹��� �����Ѵ�.
 */
static __exit void net32_exit(void)
{

	// free irq timer2, timer3
	//TMP DEL free_irq( IRQ_TIMER2, NULL);	
	free_irq( IRQ_TIMER3, NULL);
	
   	// free kernel thread memory
    if ( kthread->running ) {
    	 printk("[kthread]: kthread stopd\n");
    	kthread_stop(kthread->thread);
    }
    kfree(kthread);
    kthread = NULL;

	//kfree(pInfo);
	
    printk("[NET32]: module unloaded\n");
}

module_init(net32_init);
module_exit(net32_exit);
MODULE_AUTHOR("jong2ry@imecasys.com");
MODULE_LICENSE("Dual BSD/GPL");






















/* ��Ȯ�ϰ� 2ms �� ����� timer3 �Լ�
 *
 *
 */

#if 0

static void timer3_init(void)
{
	unsigned long tcon;
	unsigned long tcnt;
	unsigned long tcfg1;
	unsigned long tcfg0;

	tcnt = 0xffff;  /* default value for tcnt */

	/* read the current timer configuration bits */

	tcon = __raw_readl(S3C2410_TCON);
	tcfg1 = __raw_readl(S3C2410_TCFG1);
	tcfg0 = __raw_readl(S3C2410_TCFG0);

	/* configure the system for whichever machine is in use */

	if (machine_is_bast() || machine_is_vr1000()) {
		/* timer is at 12MHz, scaler is 1 */
		timer_usec_ticks = timer_mask_usec_ticks(1, 12000000);
		tcnt = 12000000 / HZ;

		tcfg1 &= ~S3C2410_TCFG1_MUX4_MASK;
		tcfg1 |= S3C2410_TCFG1_MUX4_TCLK1;
	} else {
		unsigned long pclk;
		struct clk *clk;

		/* for the h1940 (and others), we use the pclk from the core
		 * to generate the timer values. since values around 50 to
		 * 70MHz are not values we can directly generate the timer
		 * value from, we need to pre-scale and divide before using it.
		 *
		 * for instance, using 50.7MHz and dividing by 6 gives 8.45MHz
		 * (8.45 ticks per usec)
		 */

		/* this is used as default if no other timer can be found */

		clk = clk_get(NULL, "timers");
		if (IS_ERR(clk))
			panic("failed to get clock for system timer");

		clk_use(clk);
		clk_enable(clk);

		pclk = clk_get_rate(clk);
		
		printk("pclk = %ld\n", pclk);
	
		/* configure clock tick */

/*
* priod = (prescaler value + 1) * (divider value) * buffer count / PCLK = 10 ms
*
* e.g.; PCLK = 50 Mhz
* 10 ms = (15 + 1) * 2 * 15625 / (50000 * 1000)
* 15626 = 10 ms * (50000 * 1000) / 2 / (15 + 1)
*
* priod = (prescaler value + 1) * (divider value) * buffer count / PCLK = 2 ms
* e.g.; PCLK = 50 Mhz
* 2 ms = (0 + 1) * 2 * 15625 / (50000 * 1000)
* 15626 = 2 ms * (50000 * 1000) / 2 / (0 + 1)
*
*/
#if 0
		timer_usec_ticks = timer_mask_usec_ticks(6, pclk);

		tcfg1 &= ~S3C2410_TCFG1_MUX3_MASK;
		tcfg1 |= S3C2410_TCFG1_MUX3_DIV2;

		tcfg0 &= ~S3C2410_TCFG_PRESCALER1_MASK;
		tcfg0 |= ((6 - 1) / 2) << S3C2410_TCFG_PRESCALER1_SHIFT;

		tcnt = (pclk / 6) / HZ;
#else		
		timer_usec_ticks = timer_mask_usec_ticks(6, pclk);
		
		tcfg1 &= ~S3C2410_TCFG1_MUX3_MASK;
		tcfg1 |= S3C2410_TCFG1_MUX3_DIV2;		

		tcfg0 &= ~S3C2410_TCFG_PRESCALER1_MASK;
		tcfg0 |= ((6 - 1) / 2)  << S3C2410_TCFG_PRESCALER1_SHIFT;
		
		//tcnt = (unsigned int) (pclk / ((PRESCALAR4 + 1) * DIV4)) / HZ
		//tcnt = pclk/1000;
		//tcnt = (pclk / 6) / HZ;
		tcnt = 16900;
#endif		
	}

	/* timers reload after counting zero, so reduce the count by 1 */

	tcnt--;

	//printk("timer tcon=%08lx, tcnt %04lx, tcfg %08lx,%08lx, usec %08lx\n",
	//       tcon, tcnt, tcfg0, tcfg1, timer_usec_ticks);

	/* check to see if timer is within 16bit range... */
	if (tcnt > 0xffff) {
		panic("setup_timer: HZ is too small, cannot configure timer!");
		return;
	}

	__raw_writel(tcfg1, S3C2410_TCFG1);
	__raw_writel(tcfg0, S3C2410_TCFG0);

	timer_startval = tcnt;
	__raw_writel(tcnt, S3C2410_TCNTB(3));

	/* ensure timer is stopped... */

	tcon &= ~(7<<16);
	tcon |= S3C2410_TCON_T3RELOAD;
	tcon |= S3C2410_TCON_T3MANUALUPD;

	__raw_writel(tcon, S3C2410_TCON);
	__raw_writel(tcnt, S3C2410_TCNTB(3));
	__raw_writel(tcnt, S3C2410_TCMPB(3));

	/* start the timer running */
	tcon |= S3C2410_TCON_T3START;
	tcon &= ~S3C2410_TCON_T3MANUALUPD;
	__raw_writel(tcon, S3C2410_TCON);

	//printk("9 tcon = 0x%x\n", tcon);
	//printk("10 tcfg1 = 0x%x\n", tcfg1);
	//printk("11 tcfg0 = 0x%x\n", tcfg0);		
	//printk("12 tcnt = 0x%x\n", tcnt);	

	printk("timer setting \ntcon=%08lx, \ntcnt %04lx, \ntcfg %08lx, %08lx, \nusec %08lx\n",
	       tcon, tcnt, tcfg0, tcfg1, timer_usec_ticks);
}


#endif


